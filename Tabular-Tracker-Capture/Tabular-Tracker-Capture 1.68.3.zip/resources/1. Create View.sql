 
CREATE VIEW view_userlist AS 


select uinf.uid as useruid
, uinf.userinfoid 
, urs.userid
, uinf.firstname
, uinf.surname
, urs.username
, urs.disabled
, urs.lastlogin


from users urs 
INNER JOIN userinfo uinf on urs.userid=uinf.userinfoid