
var _appManifest = $.parseJSON( RESTUtil.getSynchData( 'manifest.webapp' ) );			
var _appURL = _appManifest.activities.dhis.href.replace( '/dhis-web-maintenance-appmanager', '' ) + '/';
var baseURL = _appURL + 'api/';


jQuery( document ).ready( function() {

	jQuery( "#tabDiv" ).tabs( {active: 0} );
	
	new UserManagement();
	
});


// -- End of Message Manager Class
// -------------------------------------


// -----------------------------------------------------------------------------
// -- Form Events
// ---------

function UserManagement()
{
	var me = this;
	
	me.PARAM_LEVEL = "@PARAM_LEVEL";
	me.PARAM_ORGUNIT_ID = "@PARAM_ORGUNIT_ID";
	me._QUERY_USER_FIELDS = "id,name,userCredentials[username,disabled,lastLogin,userRoles[id,name]],attributeValues[value,attribute[id,optionSet[id],userGroups[id,name],organisationUnits[id,name,level,ancestors[id,name,level]],level";
	me._URL_QUERY_GET_ALL_USERS = baseURL + "users.json?filter=organisationUnits:eq:0&paging=false&fields=" + me._QUERY_USER_FIELDS;	
	me._URL_QUERY_GET_USERS_BY_ORGUNIT = baseURL + 'users.json?includeChildren=true&ou=' + me.PARAM_ORGUNIT_ID + '&paging=false&fields=' + me._QUERY_USER_FIELDS;


	me.divListLoadingTag = $( "#divListLoading" );
	me.tabTag = $( "#tabDiv" );
	me.userWithOUsTag = $( "div.userWithOUs" );
	
	me.excelDataDivTag = $( "#excelDataDiv" );
	
	me.searchDivTag = $( "#searchDiv" )
	me.searchUsernameTag = $( "#searchUsernameTxt" );
	me.searchOUKeyPopupBtn = $( "#searchOUKeyPopupBtn" );
	me.inheritedChk = $( "#inheritedChk" );
	me.closeButtonTag = $("[name='closeButton']");
	me.addUserBtnTag = $("#addUserBtn");
	me.addUserTdTag = $("[name='addUserTd']");

	me.userManagementViewTblContainnerDivTag = $("#userManagementViewTblContainner");
	me.userRolesViewTblContainnerDivTag = $("#userRolesViewTblContainner");
	me.userGroupsViewTblContainnerDivTag = $("#userGroupsViewTblContainner");
	
	me.viewType_ManagementView = 'managementView';
	me.viewType_RoleView = 'roleView';
	me.viewType_GroupView = 'groupView';
	me.viewType_WithoutOU = 'usersWithoutOrgUnitsDiv';
	
	
	me.userRoleViewTab = $( "#userRoleViewDiv" );
	me.userGroupViewTab = $( "#userGroupViewDiv" );
	me.usersWithoutOrgUnitsDiv = $( "#usersWithoutOrgUnitsDiv" );
	
	me.orgunit = new OrgUnit();	
	me.userSettingSaver = new UserSettingSaver();
	
	me.curUserOrgUnitLoaded = false;
	me.userRolesLoaded = false;
	me.userGroupsLoaded = false;
	me.optionSetsLoaded = false;
	
	me.reopenColumnPopup_RoleView = false;
	me.reopenColumnPopup_GroupView = false;
	me.reopenColumnPopup_ManagementView = false;
	me.reopenColumnPopup_WithoutUserView = false;
	
	me.noOrgUnit = 0;
	me.ouInProgressing = 0;
	
	me.username = "";
	me.curUserOrgUnits = 0;
	me.userRoles = [];
	me.userGroups = [];
	me.userList = [];
	me.optionSets = [];
	
	me.ADD_USER_AUTHORITY = "F_USER_ADD";
	me.CHANGE_USER_STATUS_AUTHORITY = "F_USER_VIEW";
	
	me.canChangeUserStatus = false;

	
	me.managementHeaders = [
		{
			"id" : "ippfRelation"
			,"name" : "IPPF Relation"
			,"show" : true
		}
		,{
			"id" : "lastLogin"
			,"name" : "Last Login"
			,"show" : true
		}
		,{
			"id" : "orgUnits"
			,"name" : "Org Units"
			,"show" : true
		}
		,{
			"id" : "expiryDate"
			,"name" : "Expiry Date"
			,"show" : true
		}
		,{
			"id" : "userRoles"
			,"name" : "User Roles"
			,"show" : true
		}
		,{
			"id" : "userGroups"
			,"name" : "User Groups"
			,"show" : true
		}
		,{
			"id" : "profile"
			,"name" : "Profile"
			,"show" : true
		}
		,{
			"id" : "curStatus"
			,"name" : "Enabled"
			,"show" : true
		}
	];
	
	me.withoutOUsHeaders = [
		{
			"id" : "ippfRelation1"
			,"name" : "IPPF Relation"
			,"show" : true
		}
		,{
			"id" : "lastLogin1"
			,"name" : "Last Login"
			,"show" : true
		}
		,{
			"id" : "orgUnits1"
			,"name" : "Org Units"
			,"show" : true
		}
		,{
			"id" : "expiryDate1"
			,"name" : "Expiry Date"
			,"show" : true
		}
		,{
			"id" : "userRoles1"
			,"name" : "User Roles"
			,"show" : true
		}
		,{
			"id" : "userGroups1"
			,"name" : "User Groups"
			,"show" : true
		}
		,{
			"id" : "profile1"
			,"name" : "Profile"
			,"show" : true
		}
		,{
			"id" : "curStatus1"
			,"name" : "Enabled"
			,"show" : true
		}
	];
			
	
	me.initialSetup = function()
	{		
		new Header();
		
		MsgManager.initialSetup();
	
		me.divListLoadingTag.find( 'img.users' ).show();
		me.divListLoadingTag.find( 'span.users' ).hide();		
		me.divListLoadingTag.find( 'img.userRoles' ).show();
		me.divListLoadingTag.find( 'span.userRoles' ).hide();		
		me.divListLoadingTag.find( 'img.settingData' ).show();
		me.divListLoadingTag.find( 'span.settingData' ).hide();
		
		me.showLoadingTag( true );
		
		me.retrieveData();
		
		me.closeButtonTag.click( function(){
			window.location.href = _appURL;
		});
		
		$('#tabDiv .ui-tabs-nav a[href="#usersWithoutOrgUnitsDiv"]').addClass('specialTab');
		
    };
		
	// ------------------------------------------------------------------------------------------------------------
	// Retrieve data from server
	// ------------------------------------------------------------------------------------------------------------
	
	me.retrieveData = function()
	{
		me.getCurrentUserInfo();
		me.getAllUserRole();
		me.getAllUserGroup();
		me.getAllOptionSets();
	};
	
	
	me.checkAndPopulateUserTable = function()
	{
		// Populate data after retrieving data from server
		
		if( me.userRolesLoaded && me.userGroupsLoaded && me.curUserOrgUnitLoaded && me.optionSetsLoaded == true && me.noOrgUnit == me.ouInProgressing )
		{
			// STEP 1. Get user setting for views
			me.userSettingSaver.getSettingColumns( me.username, function(){
				
				// STEP 2. Populate data in views
				me.generateDataInViews();
				
			}
			, function(){
				
				// STEP 2. Populate data in views
				me.generateDataInViews();
			});
		}
	};

	me.getCurrentUserInfo = function()
	{
		me.noOrgUnit = 0;
		me.ouInProgressing = 0;
	
		var url = baseURL + 'me.json?fields=organisationUnits[id,name,level],userCredentials[userRoles[authorities],username]';
		
		RESTUtil.getAsynchData( url, function( json_Data )
		{
			me.curUserOrgUnits = json_Data.organisationUnits;
			me.noOrgUnit = me.curUserOrgUnits.length;
			
			me.getAllUserList();
			me.curUserOrgUnitLoaded = true;
			me.checkAndPopulateUserTable();
			
			// Check if the current user has authority to add new user.
			var userRoles = json_Data.userCredentials.userRoles;
			for( var i in userRoles )
			{
				var authorities = userRoles[i].authorities;
				for( var j in authorities )
				{
					// Check if current user has authority to add a new account or not
					if( authorities[j] === "ALL" || authorities[j] === me.ADD_USER_AUTHORITY )
					{
						me.addUserBtnTag.click( function(){
							// window.location.href = _appURL + "dhis-web-maintenance-user/showAddUserForm.action";
							
							window.open( _appURL + "dhis-web-user/index.html#/users/new" );
						});
						
						me.addUserTdTag.show();
					}
					
					// Check if current user has authority to change status of a user
					if( authorities[j] === "ALL" || authorities[j] === me.CHANGE_USER_STATUS_AUTHORITY )
					{
						me.canChangeUserStatus = true;
					}
				}
			}
			
			me.username = json_Data.userCredentials.username;
	   
		}
		, function() 
		{
			console.log( 'Failed to load users' );
		});
	},
	
	me.getAllUserList = function()
	{
		me.userList = [];
		for( var i in me.curUserOrgUnits )
		{
			var orgUnit = me.curUserOrgUnits[i];
			me.getUserListByOrgunit( orgUnit );
		}
		
		me.getUserListWithoutOrgunit();
	},
	
	me.getUserListByOrgunit = function( orgUnit )
	{
		var url = me._URL_QUERY_GET_USERS_BY_ORGUNIT;
		url = url.replace( me.PARAM_LEVEL, orgUnit.level - 1 );
		url = url.replace( me.PARAM_ORGUNIT_ID, orgUnit.id );

		RESTUtil.getAsynchData( url, function( json_Data )
		{
			me.addUsersInList( json_Data );
			me.divListLoadingTag.find( 'img.users' ).hide();
			me.divListLoadingTag.find( 'span.users' ).show();
			me.ouInProgressing++;
			me.checkAndPopulateUserTable();
		}
		, function() 
		{
			console.log( 'Failed to load users' );
		});
	};
	
	me.getUserListWithoutOrgunit = function()
	{
		RESTUtil.getAsynchData( me._URL_QUERY_GET_ALL_USERS, function( json_Data )
		{
			me.populateUsersWithoutOU( json_Data.users );
			me.divListLoadingTag.find( 'img.users' ).hide();
			me.divListLoadingTag.find( 'span.users' ).show();
			me.checkAndPopulateUserTable();
		}
		, function() 
		{
			console.log( 'Failed to load users' );
		});
	};
	
	me.populateUsersWithoutOU = function( dataList )
	{	
		var withoutOUTable = me.getDataTable( me.viewType_WithoutOU );		
		me.generateTableHeader( me.getDataTable( me.viewType_WithoutOU ), me.withoutOUsHeaders );
		
		$.tablesorter.destroy( withoutOUTable, false, function() {} );
		
		for( var i=0; i < dataList.length; i++ )
		{
			var rowTag = me.createRow( dataList[i], me.viewType_WithoutOU, me.withoutOUsHeaders );
			withoutOUTable.append( rowTag );
		}
		
		me.hideColumnsInSetting( withoutOUTable, me.userSettingSaver.settingData[me.viewType_WithoutOU] );
		me.getDataTable( me.withoutOUTable ).trigger("update");
		Util.tableSorter( withoutOUTable );
		me.tabTag.find( 'span.loadingRow' ).hide();
		
		me.showLoadingTag( false );
	};
	
	me.disableUser = function( username, linkTag ) 
	{
		var confirmation = confirm("Are you sure you want to disable this user?\n\n" + username);

		if( confirmation ) 
		{
			var url = _appURL + "dhis-web-maintenance-user/disableUser.action";
			
			$.post(url, {
					username: username
				},
				function( json ) {
					var colTag = linkTag.closest("td");
					var imgTag = colTag.find("img");
					imgTag.attr("src","img/red-light.png");
					imgTag.attr("title", "Disabled");
					colTag.find(".changeToDisabled").hide();
					colTag.find(".changeToEnable").show();
					colTag.find(".status").html("false");
					
					var table = colTag.closest("table");
					table.trigger("update");
					
					MsgManager.msgAreaShow( "The username '" + username + "' is disabled." );
				});
	  
	  }
	};
	
	
	me.enableUser = function( username, linkTag ) 
	{
		var confirmation = confirm("Are you sure you want to enable this user?\n\n" + username );
		
		if( confirmation )
		{
			var url = _appURL + "dhis-web-maintenance-user/disableUser.action";
			
			 $.post( url,
				{
					username: username,
					enable: true
				},
				function( json ) {
					var colTag = linkTag.closest("td");
					var imgTag = colTag.find("img");
					imgTag.attr("src","img/green-light.png");
					imgTag.attr("title", "Enabled");
					colTag.find(".changeToEnable").hide();					
					colTag.find(".changeToDisabled").show();
					colTag.find(".status").html("true");

					var table = colTag.closest("table");
					table.trigger("update");
					
					MsgManager.msgAreaShow( "The username '" + username + "' is enabled." );
			  });
		}
	};


	me.generateDataInViews = function()
	{	
		me.divListLoadingTag.find( 'img.settingData' ).hide();
		me.divListLoadingTag.find( 'span.settingData' ).show();
	
		// STEP 1. Get the user setting data
		
		me.settingData = me.userSettingSaver.settingData;
	
		// STEP 2. Setup events for buttons
		
		me.setUp_Events();
		
		// STEP 3. Populate data in tables
		
		me.setLoadingMessage( "Populating data into tables ...");		
		
		me.generateDataTable();	

	};
	
	me.showLoadingTag = function( showed )
	{
		if( showed )
		{
			me.divListLoadingTag.show();
			me.searchDivTag.hide();
			me.tabTag.hide();
		}
		else
		{
			me.divListLoadingTag.hide();
			me.searchDivTag.show();
			me.tabTag.show();
		}
	};

	me.addUsersInList = function( list )
	{
		var data = list.users;
		if( data != undefined )
		{
			for( var i in data )
			{
				var user = data[i];
				var userId = user.id;
				var userIdList = me.userList.map(x => x.id);
				if( userIdList.indexOf( userId ) < 0 )
				{
					me.userList.push( user );
				}
			}
		}
	},
	
	
	me.getAllUserRole = function()
	{
		var url = baseURL + 'userRoles.json?paging=false&fields=name,id';
		
		RESTUtil.getAsynchData( url, function( json_Data )
		{
			me.userRoles = Util.sortByKey( json_Data.userRoles, "name" );
			me.divListLoadingTag.find( 'img.userRoles' ).hide();
			me.divListLoadingTag.find( 'span.userRoles' ).show();
			me.userRolesLoaded = true;
			me.checkAndPopulateUserTable();
		}
		, function() 
		{
			alert( 'Failed to load user roles' );
		});
	};
	
	me.getAllUserGroup = function()
	{
		var url = baseURL + 'userGroups.json?paging=false&fields=name,id';
		
		RESTUtil.getAsynchData( url, function( json_Data )
		{
			me.userGroups = json_Data.userGroups;
			me.divListLoadingTag.find( 'img.userGroups' ).hide();
			me.divListLoadingTag.find( 'span.userGroups' ).show();
			me.userGroupsLoaded = true;	
			me.checkAndPopulateUserTable();			
		}
		, function() 
		{
			alert( 'Failed to load user groups' );
		});
	};

	
	me.getAllOptionSets = function()
	{
		var url = baseURL + 'optionSets.json?paging=false&fields=id,options[id,code,name]';
		
		RESTUtil.getAsynchData( url, function( json_Data )
		{
			me.optionSets = json_Data.optionSets;
			me.divListLoadingTag.find( 'img.optionSets' ).hide();
			me.divListLoadingTag.find( 'span.optionSets' ).show();
			me.optionSetsLoaded = true;	
			me.checkAndPopulateUserTable();			
		}
		, function() 
		{
			alert( 'Failed to load option sets' );
		});
	};
	
		
	me.generateDataTable = function()
	{
		// STEP 0. Create tables
		me.userManagementViewTblContainnerDivTag.html("").append("<table class='dataTable table table-hover' id='userManagementViewTbl'></table>");
		me.userRolesViewTblContainnerDivTag.html("").append("<table class='dataTable table table-hover' id='userRolesViewTbl'></table>");
		me.userGroupsViewTblContainnerDivTag.html("").append("<table class='dataTable table table-hover' id='userGroupsViewTbl'></table>");

		// STEP 1. Clear table
		
		me.clearTable();
		
		// STEP 2. Generate Headers
	
		me.generateTableHeader( me.getDataTable( me.viewType_RoleView ), me.userRoles );
		me.generateTableHeader( me.getDataTable( me.viewType_GroupView ), me.userGroups );
		me.generateTableHeader( me.getDataTable( me.viewType_ManagementView ), me.managementHeaders );
		
		// STEP 3. Populate Data in views
		me.populateDataInViews( me.userList );
	};
	
	
	me.clearTable = function()
	{
		me.userWithOUsTag.find( "table.dataTable" ).html( "" );
	};
	
		
	me.generateTableHeader = function( table, dataHeaders )
	{
		var headerTag = $( "<tr></tr>" );
		headerTag.append( "<th colId='username'>Username</th>" );
		headerTag.append( "<th colId='fullname'>Fullname</th>" );
		
		for( var i in dataHeaders )
		{
			headerTag.append( "<th colId='" + dataHeaders[i].id  + "'>" + dataHeaders[i].name + "</th>" );
		}
		
		var theadTag = $( "<thead></thead>" );
		theadTag.append( headerTag );
		table.append( theadTag );
	}
	
	
	me.populateDataInViews = function( dataRows )
	{
		me.tabTag.find( 'span.loadingRow' ).show();		
		me.userWithOUsTag.find( 'table.dataTable > tbody > tr' ).remove();
	
		var managementViewTable = me.getDataTable( me.viewType_ManagementView );		
		var roleViewTable = me.getDataTable( me.viewType_RoleView );
		var groupViewTable = me.getDataTable( me.viewType_GroupView );
		
		// $.tablesorter.destroy( managementViewTable, false, function() {} );			
		// $.tablesorter.destroy( roleViewTable, false, function() {} );				
		// $.tablesorter.destroy( groupViewTable, false, function() {} );	
		
		for( var i=0; i < dataRows.length; i++ )
		{
			// setTimeout(function(){
				me.setDataInTable( dataRows[i] );
				// var rowTag = me.createRow( dataRows[i], me.viewType_ManagementView, me.managementHeaders );
				// managementViewTable.append( rowTag );
				
				// rowTag = me.createRow( dataRows[i], me.viewType_RoleView, me.userRoles );
				// roleViewTable.append( rowTag );
				
				// rowTag = me.createRow( dataRows[i], me.viewType_GroupView, me.userGroups );
				// groupViewTable.append( rowTag );
			// },0);
		}
		
		me.hideColumnsInSetting( managementViewTable, me.userSettingSaver.settingData[me.viewType_ManagementView] );
		me.hideColumnsInSetting( roleViewTable, me.userSettingSaver.settingData[me.viewType_RoleView] );
		me.hideColumnsInSetting( groupViewTable, me.userSettingSaver.settingData[me.viewType_GroupView] );
		
		// me.getDataTable( me.viewType_RoleView ).trigger("update"); 
		// me.getDataTable( me.viewType_GroupView ).trigger("update"); 
		// me.getDataTable( me.viewType_ManagementView ).trigger("update"); 
				
				
		Util.tableSorter( managementViewTable );
		Util.tableSorter( roleViewTable );
		Util.tableSorter( groupViewTable );
		
		me.tabTag.find( 'span.loadingRow' ).hide();
		
		me.showLoadingTag( false );
	};
	
	
	me.setDataInTable = function( userData ) {
		setTimeout( function(){
			
			var managementViewTable = me.getDataTable( me.viewType_ManagementView );		
			var roleViewTable = me.getDataTable( me.viewType_RoleView );
			var groupViewTable = me.getDataTable( me.viewType_GroupView );

			var rowTag = me.createRow( userData, me.viewType_ManagementView, me.managementHeaders );
			managementViewTable.append( rowTag );
			
			rowTag = me.createRow( userData, me.viewType_RoleView, me.userRoles );
			roleViewTable.append( rowTag );
			
			rowTag = me.createRow( userData, me.viewType_GroupView, me.userGroups );
			groupViewTable.append( rowTag );
		}, 0);
	}

	
	me.findAttributeValue = function( list, attrId )
	{
		var item = "";

		for( i = 0; i < list.length; i++ )
		{
			var listItem = list[i];
	
			if ( listItem["attribute"].id == attrId )
			{
				var optionSet = listItem["attribute"].optionSet;
				if( optionSet != undefined )
				{
					var optionlist = Util.getFromList( me.optionSets, optionSet.id, "id" );
					if( optionlist != undefined )
					{
						item = Util.getFromList( optionlist.options, listItem.value, "code" );
						if( item == undefined )
						{
							item = Util.getFromList( optionlist, listItem.value, "id" );
						}

						if( item != undefined )
						{
							item = item.name;
						}
						else
						{
							item = listItem.value;
						}
					}
					else
					{
						item = listItem.value;
					}
				}
				else
				{
					item = listItem.value;
				}
				break;
			}
		}
	
		return item;
	}
	

	me.createRow = function( userData, viewType, dataHeaders )
	{
		if( userData.userCredentials == undefined ) return;

		var rowTag = $( "<tr rowId='" + userData.id + "' showed='true' ></tr>" );
		
		// Username
		var username = userData.userCredentials.username;
		rowTag.append( "<td><span class='glyphicon glyphicon-user'></span> <a target='_blank' href='/dhis-web-user/index.html#/users/edit/" + userData.id + "'>" + username + "</a></td></td>"); 
		
		// Full name
		rowTag.append( "<td>" + userData.name + "</td>"); 
		
		// UserRoles / UserGroups
		var userRoles = userData.userCredentials.userRoles;
		var userGroups = userData.userGroups;

		var roleIdList = ( userRoles != undefined ) ? userRoles.map(x => x.id) : [];
		var userGroupIdList =( userGroups != undefined ) ? userGroups.map(x => x.id) : [];

		if( viewType == me.viewType_RoleView || viewType == me.viewType_GroupView )
		{
			var relationlist = ( viewType == "roleView" ) ? roleIdList : userGroupIdList;
			for( var j in dataHeaders )
			{
				var headerId = dataHeaders[j].id;
				if( relationlist.indexOf( headerId ) >= 0 )
				{
					rowTag.append( "<td>Yes</td>" );
				}
				else
				{
					rowTag.append( "<td>No</td>" );
				}
				
			}
		}
		else if( viewType == me.viewType_ManagementView || viewType == me.viewType_WithoutOU )
		{
			// IPPF Relation
			var ippfRelation = me.findAttributeValue( userData.attributeValues, "QVPMOndpH7Z" );
			rowTag.append( "<td>" + ippfRelation + "</td>" ); 
						
			// lastLogin
			var lastLogin = userData.userCredentials.lastLogin;
			lastLogin = ( lastLogin != undefined ) ? Util.formatDate( lastLogin ) : "";
			rowTag.append( "<td>" + lastLogin + "</td>" ); 
			
			
			// Org Unit Relations
			var ouList = userData.organisationUnits;
			if( ouList != undefined && ouList.length > 0 )
			{
				var details = me.getOrgUnitDetails( ouList );
				rowTag.append( "<td><img class='trafficLightGreen' src='img/green-light.png'> " + details + "</td>" );
			}
			else
			{
				rowTag.append( '<td><img class="trafficLightRed" src="img/red-light.png" title="Capture Org Unit missing"></td>' );
			}
			
			// expiryDate
			var expiryDate = me.findAttributeValue( userData.attributeValues, "JVQcj5tqW9U" ); 
			if( expiryDate == "" )
			{
				rowTag.append( '<td><img class="trafficLightGreen" src="img/green-light.png" title="[No date]"><span style="display:none;">true</span></td>' );
			}
			else if( !Util.isExpiryDate( expiryDate ) )
			{
				rowTag.append( '<td><img class="trafficLightGreen" src="img/green-light.png" title="' + Util.formatDate( expiryDate ) + '"><span style="display:none;">true</span></td>' );
			}
			else
			{
				rowTag.append( '<td><img class="trafficLightRed" src="img/red-light.png" title="Expired \n' + Util.formatDate( expiryDate ) + '"><span style="display:none;">false</span></td>' );
			}
			
			
			
			// User roles
			var userRoles = userData.userCredentials.userRoles;
			if( userRoles != undefined )
			{
				var roleNameList = userRoles.map(x => x.name);
				roleNameList = roleNameList.join('\n');
				rowTag.append( '<td><img class="trafficLightGreen userRoleFlag" style="cursor:pointer;" src="img/green-light.png" title="' + roleNameList + '" ><span style="display:none;">true</span></td>' );
			}
			else
			{
				rowTag.append( '<td><img class="trafficLightRed userRoleFlag" src="img/red-light.png" style="cursor:pointer;" title="At least 1 user role must be assigned"><span style="display:none;">false</span></td>' );
			}
			
			rowTag.find("img.userRoleFlag").click(function(){
				me.userRoleOnClick(this);
			});	
			
			// User Groups
			var userGroups = userData.userGroups;
			if( userGroups != undefined )
			{
				var userGroupNameList = userGroups.map(x => x.name);
				userGroupNameList = userGroupNameList.join('\n');
				rowTag.append( '<td><img class="trafficLightGreen userGroupFlag" src="img/green-light.png" style="cursor:pointer;"  title="' + userGroupNameList + '"><span style="display:none;">true</span></td>' );
				rowTag.find("img.userGroupFlag").click(function(){
					me.userGroupOnClick(this);
				});
			}
			else
			{
				rowTag.append( '<td><img class="trafficLightRed userGroupFlag" src="img/red-light.png" style="cursor:pointer;"  title="At least 1 user group must be assigned"><span style="display:none;">false</span></td>' );
			}
			
			rowTag.find("img.userGroupFlag").click(function(){
				me.userGroupOnClick(this);
			});
				
			// Profile column
			// Check 'Function Area', 'DHIS Utilization' and 'IPPF Relation' attribute values
			var functionArea= me.findAttributeValue( userData.attributeValues, "orxXFRp6Y4i" );
			var dhisUtilization = me.findAttributeValue( userData.attributeValues, "mhfjsIHF3si" );  
			var ippfRelation = me.findAttributeValue( userData.attributeValues, "QVPMOndpH7Z" );    
			if( functionArea != undefined &&  dhisUtilization != undefined && ippfRelation != undefined )
			{
				rowTag.append( '<td><img class="trafficLightGreen" src="img/green-light.png"><span style="display:none;">true</span></td>' );
			}
			else
			{
				var errorMessage = "";
				var count = 0;
				if( functionArea != undefined )
				{
					errorMessage += "Function Area, ";
					count++;
				}
				
				if( dhisUtilization != undefined )
				{
					errorMessage += "DHIS Utilization, ";
					count++;
				}
				
				if( ippfRelation != undefined  )
				{
					errorMessage += "IPPF Relation, ";
					count++;
				}
				
				errorMessage = errorMessage.substring( 0, errorMessage.length - 2 );
				
				var msg = ( count == 1 ) ? "is" : "are";
				errorMessage += " " + msg + " missing."
				
				rowTag.append( '<td><img class="trafficLightRed" src="img/red-light.png" title="' + errorMessage + '"><span style="display:none;">false</span></td>' );
			}
			
			
			// User current status
			var disabled = userData.userCredentials.disabled;
			var changeDisabledStatusTag = $("<a title='Click to disable this user' class='changeToDisabled' style='cursor:pointer;display:none;color:#777;'>[D]</a>");
			changeDisabledStatusTag.click( function(){
				me.disableUser( username, $(this) );
			});
			
			var changeEnabledStatusTag = $("<a title='Click to enable this user' class='changeToEnable' style='cursor:pointer;display:none;color:#777;'>[E]</a>");
			changeEnabledStatusTag.click( function(){
				me.enableUser( username, $(this) );
			});
			
			
			if( !disabled )
			{
				changeDisabledStatusTag.show();
				
				var colTag = $('<td><img title="Enabled" class="trafficLightGreen" src="img/green-light.png"><span style="display:none;" class="status">true</span> </td>');
				if( me.canChangeUserStatus )
				{
					colTag.append( changeDisabledStatusTag );
					colTag.append( changeEnabledStatusTag );
				}
				rowTag.append( colTag );
			}
			else
			{
				changeEnabledStatusTag.show();
				
				var colTag = $('<td><img title="Disabled" class="trafficLightRed" src="img/red-light.png"><span style="display:none;" class="status">false</span> </td>');				
				if( me.canChangeUserStatus )
				{
					colTag.append( changeDisabledStatusTag );
					colTag.append( changeEnabledStatusTag );
				}			
				rowTag.append( colTag );
			}
		}
		
		return rowTag;
	}
	
	me.userRoleOnClick = function(_this)
	{
		me.userWithOUsTag.find("table tr.selectedRow").removeClass("selectedRow");
		var rowId = $(_this).closest("tr").attr("rowId");
		me.userRoleViewTab.find("tr[rowId='" + rowId + "']").addClass("selectedRow");
		me.tabTag.tabs({ active: 1 });		
	},
	
	me.userGroupOnClick = function(_this)
	{
		me.userWithOUsTag.find("table tr.selectedRow").removeClass("selectedRow");
		var rowId = $(_this).closest("tr").attr("rowId");
		me.userGroupViewTab.find("tr[rowId='" + rowId + "']").addClass("selectedRow");
		me.tabTag.tabs({ active: 2 });		
	}
		
		
	me.hideColumnsInSetting = function( table, settingData )
	{
		table.find( "th" ).each( function()
		{
			var headerId = $( this ).attr( "colId" );
			var colIdx = $( this ).index() + 1;
			var settingHeader = Util.getFromList( settingData, headerId, 'id' );
			var showed = ( settingHeader === undefined ) ? true : settingHeader.show;
			showed = ( showed === undefined ) ? true : showed;	
			
			if( !showed )
			{
				table.find( 'th:nth-child(' + colIdx + ')' ).hide();
				table.find( 'td:nth-child(' + colIdx + ')' ).hide();
			}
		});
		
	};
	
	me.getOrgUnitDetails = function( ouList ) 
	{
		var shortList = "";
		var details = "";
		var moreStr = "";
		
		for( var i=0; i<ouList.length; i++ )
		{
			var orgUnit = ouList[i];
			var ouName = me.HTMLEncode( orgUnit.name );
			var level = orgUnit.level;

			if( level > 4 )
			{
				var country = Util.getFromList( orgUnit.ancestors, 4, "level" ).name;
				country = me.HTMLEncode( country );
			
				var ouLevelNames =  country + ' - ' ;
				if( level > 5 )
				{
					ouLevelNames += Util.getFromList( orgUnit.ancestors, 5, "level" ).name;
				}
				else
				{
					ouLevelNames = ouLevelNames = country + ' - ' + ouName;
				}

				if( details.indexOf( ouLevelNames ) < 0 )
				{
					details += ouLevelNames + '\n';
					if( i< 3)
					{
						shortList += ouLevelNames + ', ';
					}
					
				}
			}
			else
			{
				details += ouName + '\n';
				if( i < 3)
				{
					shortList += ouName + ', ';
				}				
			}
		}
		
		shortList = shortList.substring( 0, shortList.length - 2 );
		var count = details.split("\n").length;
		if( count > 4 ) // Always have one '\n' in the end. So 'count' will be greater than 4 if we want to get details with more than 3 orgunits
		{
			shortList += "... <span style='color:blue;font-style:italic;' title='" + details + "'>more</span>";
		}
		
		return "<span class='ouTitle'>" + shortList + "</span>";
	};
	
	me.getUsersByOuParentList = function( ouList ) 
	{
		var result = [];
		var parentList = "";
		
		for( var i in me.userList )
		{
			if( me.checkUserWithOuList( me.userList[i], ouList ) )
			{
				result.push( me.userList[i] );
			}
		}
		
		return result;
		
	};
	
	me.checkUserWithOuList = function( userData, orgUnits )
	{
		var found = false;
		var userOuList = userData[10];
		
		for( var i=0; i<orgUnits.length; i++ )
		{
			var orgUnit = orgUnits[i].id;
			if( userOuList.indexOf( orgUnit ) >= 0 )
			{
				found = true;
			}
		}
		
		return found;
	};
	
	me.HTMLEncode = function( str )
	{
		str = str.replace(/&/g, "&amp;");
		str = str.replace(/>/g, "&gt;");
		str = str.replace(/</g, "&lt;");
		str = str.replace(/"/g, "&quot;");
		str = str.replace(/'/g, "&#039;");
		return str;
	}
		
	me.getTabTag = function( viewType )
	{
		return me.tabTag.find( "div." + viewType );
	};
	
	me.getDataTable = function( viewType )
	{
		return me.getTabTag( viewType ).find( "table.dataTable" );
	};
	
	// ************************************************************************************************
	//  Search data
	// ************************************************************************************************
	
	me.searchUsersByOrgUnit = function( orgUnit )
	{
		me.tabTag.find( 'span.loadingRow' ).show();	
		me.userWithOUsTag.find( 'table.dataTable > tbody > tr' ).hide();
	
		if( orgUnit !== undefined )
		{
			me.userList = [];
			var url = baseURL + 'organisationUnits/' + orgUnit.id + ".json?fields=level,id,ancestors[id]";
			RESTUtil.getAsynchData( url, function( json_Data )
			{
				me.getUsersBySelectedOrgUnit( json_Data )
			}
			, function() 
			{
				alert( 'Failed to search users by selected Org Unit' );
			}
			, function() 
			{
				// me.divListLoadingTag.show();
			});
			
		}
		else
		{
			me.userWithOUsTag.find( 'table.dataTable > tbody > tr' ).attr( "showed", true );
			me.userWithOUsTag.find( 'table.dataTable > tbody > tr' ).show();
			me.tabTag.find( 'span.loadingRow' ).hide();	
		}
	},
	
	me.getUsersBySelectedOrgUnit = function( orgUnit )
	{
		var url = me._URL_QUERY_GET_USERS_BY_ORGUNIT;
		url = url.replace( me.PARAM_ORGUNIT_ID, orgUnit.id );

		// var searchList = json_Data.users;
		var ouList = [];
		ouList.push( orgUnit );
		if( inheritedChk.checked )
		{
			ouList = ouList.concat( orgUnit.ancestors );
		}

		me.noOrgUnit = ouList.length;
		me.ouInProgressing = 0;
		for( var i=0; i<ouList.length; i++ )
		{
			me.getUserListByOrgunit( ouList[i] );
		}

		// RESTUtil.getAsynchData( url, function( json_Data )
		// {
			
			
			
			// me.userWithOUsTag.find( 'table.dataTable > tbody > tr' ).attr( "showed", false );
			// me.displayUsersInTable( searchList );
			// me.addUsersInList( searchList );
			// me.searchUsersByName();
			
			// me.tabTag.find( 'span.loadingRow' ).hide();	
		// }
		// , function() 
		// {
		// 	alert( 'Failed to search users by selected Org Unit' );
		// }
		// , function() 
		// {
		// 	// me.divListLoadingTag.show();
		// });
		
	};
	
	me.displayUsersInTable = function( userList )
	{
		me.userWithOUsTag.find( 'table.dataTable > tbody > tr' ).hide();
		
		for( var i in userList )
		{
			me.userWithOUsTag.find( 'table.dataTable > tbody > tr[rowId="' + userList[i].id + '"]' ).attr( "showed", true );
			me.userWithOUsTag.find( 'table.dataTable > tbody > tr[rowId="' + userList[i].id + '"]' ).show();
		}
	}
		
	me.searchUsersByName = function()
	{
		me.userWithOUsTag.find( 'span.loadingRow' ).show();
		
		// Set to hide all, first
		me.userWithOUsTag.find( 'table.dataTable > tbody > tr' ).hide();
			
		var trRows = me.getDataTable( me.viewType_ManagementView ).find( 'tbody > tr[showed="true"]' );
		
		var searchKeyword = me.searchUsernameTag.val();

		if ( searchKeyword.length > 0 )
		{
			var matchedRows = trRows.find( 'td:nth-child(1),td:nth-child(2)' ).filter( function()
			{
				return $( this ).text().match( new RegExp( searchKeyword, "ig" ) );
			});

			// Show the ones the matched
			matchedRows.each( function( i )
			{
				var rowId = $( this ).closest( 'tr' ).attr( 'rowId' );
				me.userWithOUsTag.find( "tr[rowId='" + rowId + "']").show();
			});

		}
		else
		{
			me.userWithOUsTag.find( 'table.dataTable > tbody > tr[showed="true"]' ).show();
		}
		me.userWithOUsTag.find( 'span.loadingRow' ).hide();
	};
	
	me.typewatch = function()
	{
		var timer = 0;
		return function( callback, ms )
		{
			clearTimeout ( timer );
			timer = setTimeout( callback, ms );
		}  
	}();
	
	
	// ************************************************************************************************
	// Setup Events for button
	// ************************************************************************************************
	
	me.setUp_Events = function()
	{
		me.userRoleViewTab = me.getTabTag( me.viewType_RoleView );
		me.userGroupViewTab = me.getTabTag( me.viewType_GroupView );
		me.managementUserViewtab = me.getTabTag( me.viewType_ManagementView );
		me.withoutOUsTab = me.getTabTag( me.viewType_WithoutOU );
		
		// Search users by username
		
		me.searchUsernameTag.keyup( function()
		{
			me.typewatch( function()
			{
				me.searchUsersByName();

			}, 700 );
		});
		
		
		// Show Hide Columns
		
		var roleViewsConfig = me.settingData['roleView'];
		roleViewsConfig = ( roleViewsConfig === undefined || roleViewsConfig.length == 0 ) ?  me.userRoles : roleViewsConfig;
		
		var userGroupsConfig = me.settingData['userGroups'];
		userGroupsConfig = ( userGroupsConfig === undefined || userGroupsConfig.length == 0 ) ?  me.userGroups : userGroupsConfig;
		
		var managementHeadersConfig = me.settingData['managementView'];
		managementHeadersConfig = ( managementHeadersConfig === undefined || managementHeadersConfig.length == 0 ) ?  me.managementHeaders : managementHeadersConfig;
		
		var withoutOUsHeadersConfig = me.settingData['usersWithoutOrgUnitsDiv'];
		withoutOUsHeadersConfig = ( withoutOUsHeadersConfig === undefined || withoutOUsHeadersConfig.length == 0 ) ?  me.withoutOUsHeaders : withoutOUsHeadersConfig;
		
		
		me.setUp_Events_ShowHideColumns( me.userRoleViewTab, roleViewsConfig, 'rolePopup', 'roleView', me.reopenColumnPopup_RoleView );
		me.setUp_Events_ShowHideColumns( me.userGroupViewTab, userGroupsConfig, 'groupPopup', 'groupView', me.reopenColumnPopup_GroupView );
		me.setUp_Events_ShowHideColumns( me.managementUserViewtab, managementHeadersConfig,'managementPopup', 'managementView', me.reopenColumnPopup_ManagementView );
		me.setUp_Events_ShowHideColumns( me.withoutOUsTab, withoutOUsHeadersConfig, 'usersWithoutOrgUnitsPopup', 'usersWithoutOrgUnitsDiv', me.reopenColumnPopup_WithoutUserView );
		
		
		// Download excel file
		// Excel download click setup
		
		me.userRoleViewTab.find( 'a.downloadXls' ).click( function()
		{
			var $table = me.resolveTableBeforeExport( me.userRoleViewTab );		
			me.exportToCvsFile.apply(this, [$table, 'userRolesView.csv']);
			
		});
		
		me.userGroupViewTab.find( 'a.downloadXls' ).click( function()
		{
			var $table = me.resolveTableBeforeExport( me.userGroupViewTab );		
			me.exportToCvsFile.apply(this, [$table, 'userGroupsView.csv']);
		});
			
		me.managementUserViewtab.find( 'a.downloadXls' ).click( function()
		{
			var $table = me.resolveTableBeforeExport( me.managementUserViewtab );		
			me.exportToCvsFile.apply(this, [$table, 'userManagementView.csv']);
		});
		
		me.usersWithoutOrgUnitsDiv.find( 'a.downloadXls' ).click( function()
		{
			var $table = me.resolveTableBeforeExport( me.usersWithoutOrgUnitsDiv );		
			me.exportToCvsFile.apply(this, [$table, 'usersWithoutOrgUnits.csv']);
		});
			
			
		// Org Unit Filter
		
		me.searchOUKeyPopupBtn.click( function(e)
		{
			me.orgunit.openForm( me.searchUsersByOrgUnit );			
		});

	};
	
	
	me.setUp_Events_ShowHideColumns = function( tabTag, colData, dialogId, viewType, reopen )
	{
		tabTag.find( 'button.showHideColumns' ).click( function()
		{
			var dialog = new ColumnDialog( me.username, tabTag, colData, dialogId, viewType, me.userSettingSaver, reopen );
			dialog.openForm();
			
			reopen = true;
		});
	};
	
		me.resolveTableBeforeExport = function( tab )
	{
		// Clear hidden contents - for case with previously generated table tags
		
		me.excelDataDivTag.html( "" );
		

		// Create copy of the table inside hidden div
		
		var datatableTag = tab.find( 'table.dataTable' ).clone().attr( "id", "downloadExcelTbl" );

		me.excelDataDivTag.append( datatableTag );
		
		// Hidden cells which is set by using "search user" or "filter by Ou"
		datatableTag.find( "tr" ).filter(function() {
		  return $(this).css('display') == 'none';
		}).remove();
		
		
		datatableTag.find( "th" ).filter(function() {
		  return $(this).css('display') == 'none';
		}).remove();
				
		
		// Convert 'th' tag to 'td' tag
		var headerTags = datatableTag.find( "th" );
		headerTags.replaceWith(function() {
			return $('<td/>', {
				html: this.innerHTML
			});
		});
		
		datatableTag.find( "td" ).filter(function() {
		  return $(this).css('display') == 'none';
		}).remove();
		
		
		// Fill "more" information for ouData and remove '... more' word in data
				
		datatableTag.find( "span.ouTitle" ).each( function() {
			var cell = $( this ).closest( "td" );
			var details = "";
			
			var details = $( this ).find( "span" ).attr( "title" );
			if( details === undefined || details == "" )
			{	
				details = $( this ).html().split( ", " ).join( "; " );
			}
			else
			{
				details = details.split( "\n" ).join( "; " );
				details = details.substring( 0, details.length - 2 );
			}
			
			if( details == '' )
			{
				details = "FALSE";
			}
			else
			{
				details = "TRUE - " + details;
			}
			cell.html( details );
		});
		
		
		// Set the background for traffic light cells && and remove the traffic light images
		
		var greenTrafficTag = datatableTag.find( "img.trafficLightGreen" );
		var greenTrafficCellTag = greenTrafficTag.closest( "td" );
		greenTrafficCellTag.html( greenTrafficCellTag.find("span" ).html() );
		greenTrafficTag.remove();
		
		var redTrafficTag = datatableTag.find( "img.trafficLightRed" );
		var redTrafficCellTag = redTrafficTag.closest( "td" );
		redTrafficCellTag.html( redTrafficCellTag.find("span" ).html() );
		redTrafficTag.remove();
		
		
		// Remove User Icons and User links
		
		var userIconTag = datatableTag.find( 'span.glyphicon-user' );
		userIconTag.remove();
		
		var linkTags = datatableTag.find( "a" );
		linkTags.replaceWith(function() {
			return $('<span/>', {
				html: this.innerHTML
			});
		});
		
		return datatableTag;
		
	};
	
	me.exportToCvsFile = function( $table, filename ) 
	{
        var $rows = $table.find('tr:has(td)'),

            // Temporary delimiter characters unlikely to be typed by keyboard
            // This is to avoid accidentally splitting the actual contents
            tmpColDelim = String.fromCharCode(11), // vertical tab character
            tmpRowDelim = String.fromCharCode(0), // null character

            // actual delimiter characters for CSV format
            colDelim = '","',
            rowDelim = '"\r\n"',

            // Grab text from table into CSV formatted string
            csv = '"' + $rows.map(function (i, row) {
                var $row = $(row),
                    $cols = $row.find('td');

                return $cols.map(function (j, col) {
                    var $col = $(col),
                        text = $col.text();

                    return text.replace(/"/g, '""'); // escape double quotes

                }).get().join(tmpColDelim);

            }).get().join(tmpRowDelim)
                .split(tmpRowDelim).join(rowDelim)
                .split(tmpColDelim).join(colDelim) + '"',

            // Data URI
            csvData = 'data:application/csv;charset=utf-8,' + encodeURIComponent(csv);

        $(this)
            .attr({
            'download': filename,
                'href': csvData,
                'target': '_blank'
        });
    }
	
		
	me.setLoadingMessage = function( message )
	{
		var messageTag = me.divListLoadingTag.find( 'span.message' );
		message = message + "\n" + messageTag.html();
		messageTag.html( message );
	};
	
	
	/** Run initial data **/
	
	me.initialSetup();
	
}

function ColumnDialog( _username, _tabDiv, _headerData, _dialogId, _viewType, _userSettingSaver, _reOpen )
{
	var me = this;
	me.username = _username;
	me.tabDiv = _tabDiv;
	me.headerData = _headerData;
	me.userSettingSaver = _userSettingSaver;
	me.viewType = _viewType;
	me.reOpen = _reOpen;
	me.settingHeaderData = me.userSettingSaver.settingData[me.viewType];
	me.dialogForm = $( "#" + _dialogId );
	
	me.width = 450;
	me.height = 600;
	
	
	me.initialSetup = function()
	{
		if( !me.reOpen )
		{
			var table = me.dialogForm.find( 'table.colList' );
			me.columnToogle( table );
		}
	}
	
	me.openForm = function()
	{
		me.dialogForm.dialog({
			title: 'Select columns to show'
			,maximize: true
			,closable: true
			,modal: true
			,width: me.width
			,height: me.height
			,close: function()
			{
				var dataChanged = eval( me.dialogForm.find( 'table.colList' ).attr( "changed" ) );
				if( dataChanged )
				{
					me.userSettingSaver.saveSettingDataByViewType( me.username, me.viewType, me.headerData );
					me.dialogForm.find( 'table.colList' ).attr( "changed", false );
				}
			}
			,buttons: {
				"Close": function () {
					$( this ).dialog( "close" );
				}
			}
		});	
		
	};
	
	me.columnToogle = function( table )
	{
		// STEP 1. Clear table content and Set attribute 'Changed' as 'false'
		table.html( "" );
		table.attr( "changed", false );
		
		// STEP 2. Add an Check box to select all columns
		var rowTag = $( "<tr></tr>" );
		rowTag.append( "<th><h3>Select columns to show</h3></th>" );
		rowTag.append( "<th><input colId='checkAllChk' type='checkbox' ></th>" );
		
		var theadTag = $( "<thead></thead>" );
		theadTag.append( rowTag )
		table.append( theadTag );
		
		// STEP 3. Generate column with a checkbox as a row
		
		var allOptionsChecked = true;
		
		for( var i in me.headerData )
		{
			var header = me.headerData[i];
			var status = true;
			
			var settingHeader = Util.getFromList( me.settingHeaderData, header.id, 'id' );
			if( settingHeader === undefined )
			{
				status = ( header.show === undefined ) ? true : header.show;
			}
			else
			{
				status = ( settingHeader.show === undefined ) ? true : settingHeader.show;
			}
			
			if( !status )
			{
				allOptionsChecked = false;
			}
			
			var checked = ( status ) ? "checked" : "";
			var rowTag = $( "<tr></tr>" );
			rowTag.append( "<td>" + header.name + "</td>" );
			rowTag.append( "<td><input colId='" + header.id + "' type='checkbox' " + checked + "></td>" );
			table.append( rowTag );
		}
		
		// STEP 4. Set status for 'Select All' checkbox
		
		table.find( "input[type='checkbox'][colId='checkAllChk']").prop( "checked", allOptionsChecked );
				
		// STEP 5. Add events for checkboxes
		var checkAllCkh = table.find( "input[type='checkbox'][colId='checkAllChk']");
		var colCheckBoxes = table.find( "input[type='checkbox'][colId!='checkAllChk']");
		
		checkAllCkh.change( function()
		{
			var checked = eval( $( this ).prop( "checked" ) );
			
			colCheckBoxes.prop( "checked", checked );
			colCheckBoxes.change();
		} );
		
		colCheckBoxes.change( function(){
			
			table.attr( "changed", "true" );
			var checked = eval( $( this ).prop( "checked" ) );
			
			var colId = $( this ).attr( "colId" );
			
			var data = Util.getFromList( me.headerData, colId, 'id' );
			data.show = checked;				
			
			var userTable = me.tabDiv.find( "table.dataTable" );
			var colIdx = userTable.find( 'th[colId="' + colId + '"]' ).index() + 1; // Index of a column starts from 0
			me.showHideColumn( userTable, colIdx, checked );
			
			if( me.checkSelectAll( table ) )
			{
				checkAllCkh.prop( "checked", true );
			}
			else
			{
				checkAllCkh.prop( "checked", false );
			}
					
		} );
	}
	
	me.checkSelectAll = function( table )
	{
		var checkAll = true;
		table.find( "input[type='checkbox'][colId!='checkAllChk']").each( function(){
			var checked = eval( $( this ).prop( "checked" ) );
			if( !checked )
			{
				checkAll = false;
			}
		});	
		return checkAll;
	};
	
	me.showHideColumn = function( table, colIdx, showed )
	{
		if( showed )
		{
			table.find( 'th:nth-child(' + colIdx + ')' ).show();
			table.find( 'td:nth-child(' + colIdx + ')' ).show();
		}
		else{
			table.find( 'th:nth-child(' + colIdx + ')' ).hide();
			table.find( 'td:nth-child(' + colIdx + ')' ).hide();
		}
		
	};

	
	me.initialSetup();
	
}

function UserSettingSaver()
{
	var me = this;
	
	me.PARAMS_USERNAME = "@PARAMS_USERNAME";
	
	me.settingData = {
		"roleView": []
		,"groupView": []
		,"managementView": []
		,"usersWithoutOrgUnitsDiv": []
	};
	
	
	// me.queryURL_SystemSettings = baseURL + 'systemSettings/userManagementAppSetting_' + me.PARAMS_USERNAME + '/';
	me.queryURL_SystemSettings = baseURL + 'dataStore/userManagementAppSetting/' + me.PARAMS_USERNAME;
	
	me.getSettingColumns = function( username, exeFunc, initFunc )
	{
		var url = me.queryURL_SystemSettings;
		url = url.replace( me.PARAMS_USERNAME, username );
		
		RESTUtil.getAsynchData( url
		, function( json_Data )
		{
			me.settingData = json_Data;
			exeFunc();
		}
		,function()
		{
			me.saveSettingData( username, "POST", me.settingData );
			initFunc();
		});
	};
	
	
	me.saveSettingDataByViewType = function( username, viewType, json_Data )
	{
		MsgManager.msgAreaShow( "Column configuration is saving ..." );
		me.settingData[viewType] = json_Data;
		me.saveSettingData( username, "PUT", me.settingData );
	};
	
	me.saveSettingData = function( username, requestType, json_Data )
	{
		var url = me.queryURL_SystemSettings;
		url = url.replace( me.PARAMS_USERNAME, username );
		
		RESTUtil.submitData_Text( url, requestType, json_Data
		, function()
		{
			MsgManager.msgAreaShow( "Column configuration is saved." );
		}, function(){});
	}
}					


function MsgManager() 
{}

// --- Messaging ---
MsgManager.divMsgAreaTag;
MsgManager.spanMsgAreaCloseTag;
MsgManager.btnMsgAreaCloseTag;
MsgManager.spanMsgAreaTextTag;

MsgManager.initialSetup = function()
{
	MsgManager.divMsgAreaTag = $( '#divMsgArea' );
	MsgManager.spanMsgAreaCloseTag = $( '#spanMsgAreaClose' );
	MsgManager.btnMsgAreaCloseTag = $( '#btnMsgAreaClose' );
	MsgManager.spanMsgAreaTextTag = $( '#spanMsgAreaText' );
		
	MsgManager.btnMsgAreaCloseTag.click( function()
	{
		MsgManager.divMsgAreaTag.hide( 'fast' );
	});
	
};

MsgManager.msgAreaShow = function( msg )
{
	MsgManager.spanMsgAreaTextTag.text( msg );
	MsgManager.divMsgAreaTag.show( 'medium' );
};


	