/**
 * Created by Tran on 8/5/2015.
 */


function OrgUnit()
{
    var me = this;
	
	me.dialogForm = $( "#ouFilterDiv" );
	me.searchOUKeyTextTag = $( "#searchOUKeyText" );
	me.width = 400;
	me.height = 540;
	
	me.selected = [];	
		
    me.initialSetup = function()
	{
		me.buildTree();
    };

    me.buildTree = function()
    {
		selectionTreeSelection.setMultipleSelectionAllowed( false );
		selectionTree.clearSelectedOrganisationUnits();
		selectionTree.buildSelectionTree();
		selectionTreeSelection.setListenerFunction( me.listenerFunction );	
    };

    me.listenerFunction = function( orgUnits, orgUnitNames )
    { 
        me.selected = [];
		for( var i=0; i< orgUnits.length; i++ ) 
		{
			var parents = selectionTree.getParents( orgUnits[i] );
			me.selected.push({ "id": orgUnits[i], "name": orgUnitNames[i], "parents": parents, "level" : parents.length + 1 });			
        }
    };
	
	me.getSelected = function()
	{
		return me.selected;
	}
	
	me.openForm = function( filterFunc )
	{
		me.dialogForm.dialog({
			title: 'Org Unit Filter',
			maximize: false,
			closable: true,
			modal: true,
			width: me.width,
			height: me.height,
			buttons: {
				"Filter": function () {
					if( me.selected.length > 0 )
					{
						me.searchOUKeyTextTag.val( me.selected[0].name );						
						filterFunc( me.selected[0] );
					}
					else{
						me.searchOUKeyTextTag.val( "" );
						filterFunc();
					}
					
					$( this ).dialog( "close" );
					
				}
				,"Close": function () {
					$( this ).dialog( "close" );
				}
			}
		});
	}
	

	// Run Initial Setup
	
	me.initialSetup();
}

