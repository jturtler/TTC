select DISTINCT uinf.useruid , uinf.userid , uinf.firstname , uinf.surname , uinf.username , uinf.disabled , uinf.lastlogin , 

( select attval.value from userattributevalues userattr inner join "attributevalue" attval on attval.attributevalueid=userattr.attributevalueid inner join "attribute" attr on attr.attributeid=attval.attributeid where attr.uid='JVQcj5tqW9U' and userattr.userinfoid=uinf.userinfoid ) as "expirationdate" , 

( select array_to_string(array( select ursrole.uid from view_userlist _urs inner join userrolemembers rolemember on rolemember.userid = _urs.userid inner join userrole ursrole on ursrole.userroleid = rolemember.userroleid where _urs.userid = uinf.userid ), ', ') ) as userrole_list , 

( select array_to_string(array( select usrgroup.uid from view_userlist _urs inner join usergroupmembers groupmember on groupmember.userid = _urs.userid inner join usergroup usrgroup on usrgroup.usergroupid = groupmember.usergroupid where _urs.userid = uinf.userid ), ', ') ) as usergroup_list ,

( select array_to_string(array( select '{"id":"' || org.uid || '","name":"' || org.name || '","level":"' || orgstr.level || '","country":"' || COALESCE(( select name from organisationunit where organisationunitid=orgstr.idlevel4 ),'') || '","level5":"' || COALESCE(( select name from organisationunit where organisationunitid=orgstr.idlevel5 ),'') || '"}' from usermembership orgmember inner join organisationunit org on org.organisationunitid=orgmember.organisationunitid inner join "_orgunitstructure" orgstr on orgstr.organisationunitid = org.organisationunitid where orgmember.userinfoid = uinf.userinfoid ), ', ') ) as org_list , 


( select optvalue.name from userattributevalues userattr 
inner join "attributevalue" attval on attval.attributevalueid=userattr.attributevalueid 
inner join "attribute" attr on attr.attributeid=attval.attributeid 
inner join "optionvalue" optvalue on attr.optionsetid=optvalue.optionsetid
where attr.uid='orxXFRp6Y4i' and userattr.userinfoid=uinf.userinfoid and attval.value=optvalue.code )  as "functionalArea" ,


( select optvalue.name from userattributevalues userattr 
inner join "attributevalue" attval on attval.attributevalueid=userattr.attributevalueid 
inner join "attribute" attr on attr.attributeid=attval.attributeid 
inner join "optionvalue" optvalue on attr.optionsetid=optvalue.optionsetid
where attr.uid='mhfjsIHF3si' and userattr.userinfoid=uinf.userinfoid and attval.value=optvalue.code ) as "utilisationOptions" ,



( select optvalue.name from userattributevalues userattr 
inner join "attributevalue" attval on attval.attributevalueid=userattr.attributevalueid 
inner join "attribute" attr on attr.attributeid=attval.attributeid 
inner join "optionvalue" optvalue on attr.optionsetid=optvalue.optionsetid
where attr.uid='QVPMOndpH7Z' and userattr.userinfoid=uinf.userinfoid and attval.value=optvalue.code) as "IPPFRelation" ,



( select array_to_string(array( select ursrole.name from view_userlist _urs 
inner join userrolemembers rolemember on rolemember.userid = _urs.userid 
inner join userrole ursrole on ursrole.userroleid = rolemember.userroleid where _urs.userid = uinf.userid ), ', ') ) as userrole_name_list , 

( select array_to_string(array( select usrgroup.name from view_userlist _urs inner join usergroupmembers groupmember on groupmember.userid = _urs.userid 
inner join usergroup usrgroup on usrgroup.usergroupid = groupmember.usergroupid where _urs.userid = uinf.userid ), ', ') ) as usergroup_name_list 



 from view_userlist uinf where uinf.useruid in ( select uinf.useruid from view_userlist uinf inner join usermembership orgmember on orgmember.userinfoid = uinf.userinfoid inner join organisationunit org on org.organisationunitid=orgmember.organisationunitid inner join "_orgunitstructure" orgstr on orgstr.organisationunitid = org.organisationunitid where orgstr.uidlevel${level} = '${ouid}' ) order by username