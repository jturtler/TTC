(document).ready(function(){
  $('.table-fixed-header').fixedHeader();
});